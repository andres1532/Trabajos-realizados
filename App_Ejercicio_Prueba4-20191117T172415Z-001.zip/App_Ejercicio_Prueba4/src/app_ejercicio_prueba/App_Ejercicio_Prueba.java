/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_ejercicio_prueba;

//import Control.ControlUsuario;
import Modelo.Usuario;

/**
 *
 * @author Jhonny Londoño G
 */
public class App_Ejercicio_Prueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        ControlUsuario objce=new ControlUsuario();
//        Usuario obje=new Usuario("id", "contra","nom", "ape", "tel", "corre", 10, 20,3 );
//        boolean f=objce.insertarUsuario(obje);
        
//        if(f){
//            
//            System.out.println("Se inserto el usuario");
//        }else{
//            System.out.println("No se inserto el usuario");
//        }
//        
    }
    
}
